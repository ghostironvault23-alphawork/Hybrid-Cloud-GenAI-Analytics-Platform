# API Documentation

## GET `/health`

Checks backend health.

## POST `/ingest/event`

Ingests one event.

### Body

```json
{
  "source_type": "cloud_log",
  "source_name": "aws-cloudwatch-payment-service",
  "event_id": "cloud-001",
  "timestamp": "2026-05-26T09:15:00Z",
  "severity": "error",
  "message": "Payment service returned HTTP 500.",
  "attributes": {
    "service": "payment-service"
  }
}
```

## POST `/ingest/batch`

Ingests multiple events.

## POST `/ask-ai`

Asks the AI analyst a question.

### Body

```json
{
  "question": "Why did payment service fail?",
  "user_id": "demo-user",
  "role": "Engineer",
  "max_context_events": 5
}
```

## GET `/events/search?q=payment`

Searches local data lake events.

## GET `/reports/summary`

Returns event count, source distribution, severity distribution, and latest events.
