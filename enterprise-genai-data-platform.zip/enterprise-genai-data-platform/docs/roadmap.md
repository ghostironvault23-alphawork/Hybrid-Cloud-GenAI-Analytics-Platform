# Roadmap

## Phase 1: Local MVP

- FastAPI backend
- Local data lake
- SQLite transaction database
- Mock AI service
- Static frontend
- Sample ingestion scripts

## Phase 2: AWS Serverless

- S3 data lake
- API Gateway
- Lambda
- DynamoDB
- Cognito
- CloudWatch
- Bedrock

## Phase 3: Enterprise Data and AI

- Glue crawlers
- Athena analytics
- QuickSight dashboards
- Bedrock Knowledge Bases
- OpenSearch vector search
- PII detection
- Bedrock Guardrails

## Phase 4: Enterprise Scale

- ECS/EKS microservices
- Step Functions workflows
- SQS dead-letter queues
- PrivateLink / VPN / Direct Connect
- CI/CD with GitHub Actions
- Multi-account AWS strategy
