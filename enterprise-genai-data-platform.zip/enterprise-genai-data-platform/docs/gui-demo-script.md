# GUI Demo Script for Recruiter

Use this when explaining your project in an interview.

| Step | What to Show | What to Say |
|---:|---|---|
| 1 | Architecture diagram | “This platform connects users, IoT, on-prem systems, and public cloud systems into a secure AI intelligence layer.” |
| 2 | README | “This is the project overview, architecture, setup steps, and AWS mapping.” |
| 3 | Backend API docs | “FastAPI provides endpoints for ingestion, AI questions, search, and reports.” |
| 4 | Seed script | “Sample logs, IoT telemetry, and on-prem tickets are ingested into the local data lake.” |
| 5 | Frontend UI | “The user asks business or technical questions from a clean interface.” |
| 6 | AI answer | “The AI response is generated using relevant retrieved events, similar to RAG.” |
| 7 | Summary report | “This shows events by source, severity, and latest signals.” |
| 8 | Security files | “Sensitive data is masked, and role-based checks protect the AI endpoint.” |
| 9 | Infrastructure folder | “This is ready for AWS scaling using SAM or Terraform.” |

## Best Short Pitch

“I built a local MVP of a hybrid enterprise GenAI platform. It ingests data from cloud logs, IoT telemetry, and on-prem tickets. The backend validates and masks data, stores it in a data lake, retrieves relevant context, and generates AI-style root cause analysis and business insights. The project maps clearly to AWS services like S3, Lambda, API Gateway, DynamoDB, Bedrock, Glue, Athena, QuickSight, CloudWatch, IAM, and Cognito.”
