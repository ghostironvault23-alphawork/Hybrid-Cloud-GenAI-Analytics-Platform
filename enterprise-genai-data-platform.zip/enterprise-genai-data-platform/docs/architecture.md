# Architecture Guide

## Purpose

This project demonstrates a hybrid enterprise GenAI data platform. It connects users, on-prem systems, IoT devices, and public cloud systems into one secure intelligence layer.

## End-to-End Flow

```text
1. User or system sends data
2. API validates request
3. Data is masked and stored
4. Relevant context is retrieved
5. AI layer generates answer
6. Response is stored for audit
7. User receives report, summary, or recommendation
```

## Component Mapping

| Diagram Component | Local MVP | AWS Production |
|---|---|---|
| Users | Static frontend | Amplify / S3 + CloudFront |
| Authentication | Demo API key | Cognito / SSO |
| API Layer | FastAPI | API Gateway |
| Middle Layer | Python services | Lambda / ECS / EKS |
| Data Lake | Local JSONL files | S3 |
| Transaction DB | SQLite | DynamoDB / RDS |
| AI Layer | Mock AI service | Amazon Bedrock |
| Analytics | Summary endpoint | Glue + Athena + QuickSight |
| Monitoring | Console logs | CloudWatch |
| Security | Basic masking | IAM, KMS, WAF, CloudTrail |

## Security Design

- Validate all incoming data
- Mask emails, phone numbers, cards, and secrets
- Use role checks before AI access
- Store audit logs
- Keep raw data separate from processed data
- Use least privilege in production

## Production Architecture on AWS

```text
Frontend on S3/CloudFront
        ↓
Cognito Authentication
        ↓
API Gateway
        ↓
Lambda / ECS Services
        ↓
S3 Data Lake + DynamoDB
        ↓
Bedrock Knowledge Base / OpenSearch
        ↓
Amazon Bedrock
        ↓
QuickSight / Reports / Alerts
```
