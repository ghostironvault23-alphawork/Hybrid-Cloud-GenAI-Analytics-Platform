from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def should_skip(path: Path) -> bool:
    skip_parts = {".git", ".venv", "__pycache__", "runtime", ".pytest_cache"}
    return any(part in skip_parts for part in path.parts)


def main() -> None:
    for path in sorted(ROOT.rglob("*")):
        if should_skip(path):
            continue
        rel = path.relative_to(ROOT)
        depth = len(rel.parts) - 1
        prefix = "  " * depth
        marker = "📁" if path.is_dir() else "📄"
        print(f"{prefix}{marker} {rel.name}")


if __name__ == "__main__":
    main()
