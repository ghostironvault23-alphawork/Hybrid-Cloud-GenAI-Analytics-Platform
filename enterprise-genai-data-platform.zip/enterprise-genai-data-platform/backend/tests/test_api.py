from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_ask_ai_rejects_viewer_role():
    response = client.post(
        "/ask-ai",
        json={
            "question": "Why did payment service fail?",
            "user_id": "test-user",
            "role": "Viewer",
        },
    )
    assert response.status_code == 403
