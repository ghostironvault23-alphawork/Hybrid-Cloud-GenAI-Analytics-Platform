from .masking import mask_text


def normalize_severity(severity: str) -> str:
    value = severity.strip().lower()
    valid = {"debug", "info", "warning", "error", "critical"}
    return value if value in valid else "info"


def clean_message(message: str) -> str:
    compact = " ".join(message.strip().split())
    return mask_text(compact)
